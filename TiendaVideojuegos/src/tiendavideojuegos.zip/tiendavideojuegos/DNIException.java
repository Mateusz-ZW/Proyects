/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiendavideojuegos;

/**
 *
 * @author mateo
 */
public class DNIException extends Exception {
    public DNIException(String m)
    {
        super(m);
    }
}
