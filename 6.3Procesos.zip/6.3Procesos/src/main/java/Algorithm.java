/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author mateo
 */
public interface Algorithm {
    String crypt(String text) throws Exception;
    String decrypt(String text) throws Exception;
}
