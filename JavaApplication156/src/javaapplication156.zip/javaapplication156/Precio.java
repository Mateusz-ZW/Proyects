/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication156;

/**
 *
 * @author mateo
 */
public class Precio {
    private double precio;
    
    public Precio(){
        
    }
    public Precio(double precio){
        this.precio=precio;
    }
    public String toString(){
        return "El precio es: "+this.precio;
    }
    
}
